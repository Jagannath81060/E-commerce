<?php
define("DB_HOST", "localhost:3306");
define("DB_USER", "qualityn_wahed");
define("DB_PASS", "}jz0(poM.N0@");
define("DB_NAME", "qualityn_shop");
