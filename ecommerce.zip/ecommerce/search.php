<?php include 'inc/header.php'; ?>

<div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		    <h3>Search By Product</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
        <div class="section group">
			<?php 
            
            $getSearchProduct = $pd->getSearchProduct($search);
            
            if ($getSearchProduct) {
                while ($result = $getSearchProduct->fetch_assoc()) {
                    ?>
			<div class="grid_1_of_4 images_1_of_4">
				 <a href="details.php?proId=<?= $result['productId'] ?>"><img src="admin/<?= $result['image']; ?>" alt="" /></a>
				 <h2><?= $result['productName'] ?></h2>
				 <p><span class="price">&#2547;<?= $result['price'] ?></span></p>
			     <div class="button"><span><a href="details.php?proId=<?= $result['productId'] ?>" class="details">Details</a></span></div>
			</div>
			<?php
                }
            } ?>				
    	</div>
    </div>
    <?php include 'inc/footer.php'; ?>
</div>


