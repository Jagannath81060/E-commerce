<?php include 'inc/header.php'; ?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$login = Session::get("cuslogin");
if ($login == false) {
    header("Location:login.php");
}
?>
<?php 
if (isset($_GET['orderid']) && $_GET['orderid'] == 'offline') {
    $cmrId = Session::get("cmrId");
    $invqty = Session::get("invqty");
    
    $insertOrder = $ct->orderProduct($cmrId);
    
    $method=0;
    $amount= Session::get("gTotal");
    $delivery= Session::get("delivery");
    $transaction=NULL;
    $pdate= date("Y-m-d H:i:s");
    $pstatus=0;
    $odate= date("Y-m-d H:i:s");
    $ostatus=1;
    
    $paymentOrder = $ct->orderPaymentInfo($cmrId, $invqty, $method, $amount, $delivery, $transaction, $pdate, $pstatus, $odate, $ostatus);
    
    $delData = $ct->delCustomerCart();
    header("Location:success.php");
}
?>
<style type="text/css">
.division{width:50%; float:left;}
.tblone{width: 95%; margin-right:15px; border:2px solid #ddd;}
.tblone tr td{text-align: justify;}
.tbltwo{float:right; text-align:left; width:40%; border:2px solid #ddd; margin-right:14px; margin-top: -4px; margin-right: 38px;}
.tbltwo tr td{text-align:justify; padding: 5px 10px;}
.ordernow{}
.ordernow a{width:200px; margin:20px auto 0; text-align: center; padding:5px; font-size:30px; display: block; background: #3C3B40; color: white; border-radius: 3px;}
</style>

<div class="main">
	<div class="content">
		<div class="section group">
			<div class="division">
				<table class="tblone">
					<tr>
						<th>No</th>
						<th>Product</th>								
						<th>Price</th>
						<th>Quantity</th>
						<th>Total</th>								
					</tr>
					<?php 
                    $getPro = $ct->getCartProduct();
                    if ($getPro) {
                        $i=0;
                        $sum = 0;
                        $qty = 0;
                        while ($result = $getPro->fetch_assoc()) {
                            $i++; ?>
					<tr>
						<td><?= $i ?></td>
						<td><?= $result['productName'] ?></td>								
						<td>&#2547;<?= $result['price'].".00" ?></td>
						<td><?= $result['quantity'].".00" ?></td>								
						<td>&#2547;<?php $total =  $result['price'] * $result['quantity']; echo number_format($total).".00"; ?></td>								
					</tr>
					<?php $qty = $qty + $result['quantity']; Session::set("invqty", $qty); $sum = $sum + $total; ?>
					<?php
                        }
                    } ?>
				</table>
				
				
            	<div class="division">
                    <div class="select_delivery_Method">
                        <h2 class="my-3 pt-2 text-center" style="line-height: 10px">Delivery Location</h2>
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="deliveryCharge_wrapper">
                                    <ul class="list-unstyled">
                                        <li><label><input class="mr-1" name="optradio" type="radio" value="1" checked="">Inside Khulna</label></li>
                                        <br>
                                        <li><label><input class="mr-1" name="optradio" type="radio" value="2">Outside Khulna</label></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
						
				<table class="tbltwo">
					<tr>								
						<td>Sub Total</td>
						<td>:</td>
						<td>&#2547;<?= $sum ?></td>								
					</tr>
					<tr>
						<td>Delivery Charge</td>
						<td>:</td>
						<td><span id="delivery"></span></td>
					</tr>
					<tr>
						<td>Grand Total</td>
						<td>:</td>
						<td><span id="grandtotal"></span></td>
					</tr>
					<tr>								
						<td>Quantity</td>
						<td>:</td>
						<td><?= $qty ?></td>								
					</tr>
			   </table>
			</div>			
			<div class="division">
				<?php 
            $id = Session::get("cmrId");
            $getData = $cmr->getCustomerData($id);
            if ($getData) {
                while ($result = $getData->fetch_assoc()) {
                    ?>
			<table class="tblone">
				<tr>
					<td colspan="3" style="text-align: center;"><h2>Your Profile Details</h2></td>					
				</tr>
				<tr>
					<td width="20%">Name</td>
					<td width="5%">:</td>
					<td><?= $result['name'] ?></td>
				</tr>
				<tr>
					<td>Phone</td>
					<td>:</td>
					<td><?= $result['phone'] ?></td>
				</tr>
				<tr>
					<td>Email</td>
					<td>:</td>
					<td><?= $result['email'] ?></td>
				</tr>
				<tr>
					<td>Address</td>
					<td>:</td>
					<td><?= $result['address'] ?></td>
				</tr>
				<tr>
					<td>City</td>
					<td>:</td>
					<td><?= $result['city'] ?></td>
				</tr>
				<tr>
					<td>Zip Code</td>
					<td>:</td>
					<td><?= $result['zip'] ?></td>
				</tr>
				<tr>
					<td>Country</td>
					<td>:</td>
					<td><?= $result['country'] ?></td>
				</tr>
				<tr>
					<td colspan="3" style="text-align: center; font-size: 22px;"><a style="color: green;" href="editprofile.php">Update Details</a></td>
				</tr>				
			</table>
			<?php
                }
            } ?>	
			</div>			
		</div>
		<div class="ordernow">
			<a href="?orderid=offline">Order</a>
		</div>
	</div>
	<script type="text/javascript">
        $(document).ready(function(){
           $("input[type='radio']").click(function() {
               var radioValue = $("input[name='optradio']:checked").val();
        
               // this block is for Inside khulna ( id --> 1)
               if(radioValue === '1'){
                    $('#insidekhulna').show();
                    $('#outsidekhulna').hide();
                       
                    $('#delivery').html("&#2547;<?php $delivery=60; Session::set("delivery", $delivery); echo number_format($delivery).".00"; ?>");
                    $('#grandtotal').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
               }
        
               else if(radioValue === '2'){
        
                    $('#insidekhulna').hide();
                    $('#outsidekhulna').show();
                   
                    $('#delivery').html("&#2547;<?php $delivery=150; Session::set("delivery", $delivery); echo number_format($delivery).".00"; ?>");
                    $('#grandtotal').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
               }
               
           });
        
           $('#outsidekhulna').hide();
           var radioValue = $("input[name='optradio']:checked").val();
        
            // for 1 inside khulna
           if(radioValue === '1'){
                $('#insidekhulna').show();
                $('#outsidekhulna').hide();
                $('#delivery').html("&#2547;<?php $delivery=60; Session::set("delivery", $delivery); echo number_format($delivery).".00"; ?>");
                $('#grandtotal').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
               
           }
            // for 2 outside khulna
           else if(radioValue === '2'){
                $('#insidekhulna').hide();
                $('#outsidekhulna').show();
                $('#delivery').html("&#2547;<?php $delivery=150; Session::set("delivery", $delivery); echo number_format($delivery).".00"; ?>");
                $('#grandtotal').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
           }
        });
    </script>
        
    <?php include 'inc/footer.php'; ?>
</div>
