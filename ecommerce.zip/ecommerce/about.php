<?php include 'inc/header.php'; ?>

 <div class="main">
    <div class="content">
    	<div class="support">
  			<div class="support_desc">
  				<h3 class="text-success text-decoration-underline font-monospace">About Quality Nutrition</h3>
  				<!--<p><span>24 hours | 7 days a week | 365 days a year &nbsp;&nbsp; Live Technical Support</span></p>-->
  				<p class="text-info-emphasis fw-bold fs-5 fst-italic text-sm-center"> Welcome to Quality Nutrition, your trusted source for premium peanut butter and other nutritious delights! At Quality Nutrition, we are passionate about bringing you the highest quality, health-focused products that cater to your lifestyle needs.</p>
  			</div>
  				<img src="images/qualitynut.jpg" alt="" />
  			<div class="clear"></div>
  		</div>
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2 class="text-success text-decoration-underline font-monospace">Our Story</h2>
					   <p class="text-info-emphasis fw-bold fs-5 fst-italic"> Quality Nutrition was founded with a simple mission: to provide delicious, healthy, and natural food options that you can enjoy without compromise. As a proud distributor of Pintola Peanut Butter in Bangladesh, we are committed to ensuring that our products are not only tasty but also packed with the nutrients you need to thrive.</p>
				  	<h2 class="text-success text-decoration-underline font-monospace">Our Commitment</h2>
				    <h1 class="text-info fw-bolder">At Quality Nutrition, we are dedicated to:</h2>
					   <p class="text-info-emphasis fw-semibold fs-6 fst-normal m-3"> Quality: We source the best ingredients and maintain rigorous standards to ensure our products meet the highest quality benchmarks.</p>
					   <p class="text-info-emphasis fw-semibold fs-6 fst-normal m-3 ">Health: Our products are designed to support a healthy lifestyle, offering nutritious options that you can trust.</p>
					   <p class="text-info-emphasis fw-semibold fs-6 fst-normal m-3"> Customer Satisfaction: Your satisfaction is our priority. We strive to provide excellent customer service and a seamless shopping experience, whether you’re buying from our Facebook and Instagram pages or our new website.</p>
					<h2 class="text-success text-decoration-underline font-monospace">Join Our Community</h2>
				     	<p class="text-danger fw-semibold fs-6 fst-normal m-3">We are more than just a brand; we are a community of health-conscious individuals who believe in the power of good nutrition. Join us on Facebook and Instagram to stay updated on our latest products, promotions, and healthy living tips.</p>
				  </div>
  				</div>
				<div class="col span_1_of_3">
      			      <div class="company_address">
				     	<h2 class="text-success text-decoration-underline font-monospace">>Our Products</h2>
				     	<p class="text-info fw-semibold fs-6 fst-normal m-3"> We offer a variety of peanut butter options, including:</p>
				     	<p class="text-info-emphasis fw-semibold fs-6 fst-normal m-3"> Pintola All Natural Peanut Butter: Made from 100% roasted peanuts, our all-natural peanut butter is a wholesome and nutritious choice for your everyday needs.</p>
				     	<p class="text-info-emphasis fw-semibold fs-6 fst-normal m-3"> Pintola Honey Peanut Butter: A delightful blend of peanuts and honey, offering a sweet and savory taste that’s perfect for any snack or meal.</p>
				     	<p class="text-info-emphasis fw-semibold fs-6 fst-normal m-3"> Pintola High Protein Peanut Butter: Packed with protein, this option is ideal for fitness enthusiasts and anyone looking to add more protein to their diet.</p>
				        <p class="text-info-emphasis fw-semibold fs-6 fst-normal m-3"> Each of our products is crafted with care, ensuring you get the best taste and nutrition in every jar. We believe in transparency and quality, which is why all our peanut butters are USA FDA approved.</p>
                     </div>
				</div>
        </div>
        <div>
  			<div>
                    <h2 class="text-primary text-center font-monospace">Thank you for choosing Quality Nutrition. We are excited to be a part of your journey towards a healthier, happier you!</h2>
  	    	</div>
  		</div>
  		
        
 </div>
<?php include 'inc/footer.php'; ?>
