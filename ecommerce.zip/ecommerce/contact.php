<?php include 'inc/header.php'; ?>

 <div class="main">
    <div class="content">
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Contact Us</h2>
					    <form>
					    	<div>
						    	<span><label>NAME</label></span>
						    	<span><input type="text" value=""></span>
						    </div>
						    <div>
						    	<span><label>E-MAIL</label></span>
						    	<span><input type="text" value=""></span>
						    </div>
						    <div>
						     	<span><label>MOBILE NO.</label></span>
						    	<span><input type="text" value=""></span>
						    </div>
						    <div>
						    	<span><label>SUBJECT</label></span>
						    	<span><textarea> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="SUBMIT"></span>
						  </div>
					    </form>
				  </div>
  				</div>
				<div class="col span_1_of_3">
      			<div class="company_address">
				     	<h2 class="text-primary fs-3 font-monospace">Company Information :</h2>
						<p class="text-success fs-4 font-monospace">Quality Nutrition</p>
						<p>117, Upper Jessore Road, Khulna Sadar, Khulna</p>
						<p>Bangladesh</p>
				   		<p>Phone:01936617062</p>
				   		<p>Phone:01914843572</p>
				   		<p>Phone:01612039399</p>
				 	 	<p>Email: <span>info@qualitynutritionbd.com</span></p>
				   		<p>Follow on: <span><a href="https://www.facebook.com/profile.php?id=100076217506307" target="_blank" class=" fs-4">Facebook</a></span>, <span><a href="#" target="_blank" class=" fs-4"><i class="lni lni-instagram"></i>Instagram</a></span></p>
				   </div>
				 </div>
			  </div>    	
    </div>
    <?php include 'inc/footer.php'; ?>
 </div>
