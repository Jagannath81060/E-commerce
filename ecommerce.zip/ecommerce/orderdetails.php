<?php include'inc/header.php'; ?>
<?php 
$login = Session::get("cuslogin");
if ($login == false) {
    header("Location:login.php");
}
?>
<style type="text/css">
    .tblone {
        width: 100%;
        margin: 20px 0;
    }
    .tblone td, .tblone th {
        padding: 8px;
        border: 1px solid #ddd;
    }
    .tblone tr:nth-child(even) {
        background-color: #f2f2f2;
    }
</style>
<div class="main">
    <div class="content">
        <div class="section group">
            <div class="order">
                <h2>Your Ordered Details</h2>
                <div class="table-responsive">
                    <table class="tblone table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Invoice No</th>
                                <th>Invoice Date</th>
                                <th>Order ID</th>
                                <th>Order Status</th>
                                <th>Payment Status</th>
                                <th>Total Quantity</th>
                                <th>Total Price</th>
                                <th>Invoice Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $cmrId = Session::get("cmrId");
                            $getAllOrder = $ct->getAllOrderProduct($cmrId);
                            if ($getAllOrder) {
                                $i=0;
                                while ($result = $getAllOrder->fetch_assoc()) {
                                    $i++; ?>
                                    <?php
                                    $invoiceNumber = str_pad($result['invid'], 6, '0', STR_PAD_LEFT);
                                    $orderNumber = str_pad($result['orderid'], 6, '0', STR_PAD_LEFT);
                                    ?>
                            <tr>
                                <td><?= $i; ?></td>
                                <td><?= $invoiceNumber; ?></td>
                                <td><?= $fm->formatDate($result['odate']); ?></td>
                                <td><?= $orderNumber; ?></td>
                                <td>
                                <?php
                                    if ($result['ostatus'] == '0') {
                                        echo "Not Placed";
                                    } else if ($result['ostatus'] == '1') {
                                        echo "Placed";
                                    } elseif ($result['ostatus'] == '2') {
                                        echo "Approved";
                                    } elseif ($result['ostatus'] == '3') {
                                        echo "Ready to Ship";
                                    } elseif ($result['ostatus'] == '4') {
                                        echo "Handover to Courier";
                                    } elseif ($result['ostatus'] == '5') {
                                        echo "Delivered";
                                    } else {
                                        echo "Ok";
                                    }
                                ?>
                                </td>
                                <td>
                                <?php
                                    if ($result['pstatus'] == '0') {
                                        echo "Not Paid";
                                    } else if ($result['pstatus'] == '1') {
                                        echo "Paid";
                                    } elseif ($result['pstatus'] == '2') {
                                        echo "Offline Paid";
                                    } elseif ($result['pstatus'] == '3') {
                                        echo "Online Paid";
                                    } else {
                                        echo "Ok";
                                    }
                                ?>
                                </td>
                                <td class="text-center"><?= $result['invqty'].".00"; ?></td>
                                <td class="text-center">&#2547;<?= number_format($result['amount']).".00"; ?></td>
                                <td class="text-center"><a href="invoice.php?orderid=<?= $result['orderid'] ?>" target="_blank">View</a></td>
                            </tr>
                            <?php
                                }
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>
    <?php include 'inc/footer.php'; ?>
</div>
