<?php 
include 'lib/Session.php';
Session::init();
include 'lib/Database.php';
include 'helpers/Format.php';
include 'classes/Product.php';
include 'classes/Cart.php';

spl_autoload_register(function ($class) {
    include_once "classes/".$class.".php";
});
$db = new Database();
$fm = new Format();
$pd = new Product();
$ct = new Cart();
$cat = new Category();
$cmr = new Customer();
?>

<?php 
if (!isset($_GET['orderid']) || $_GET['orderid'] == null) {
    echo "<script>window.location = '404.php';</script>";
} else {
    
    $cmrId = Session::get("cmrId");
    $orderid = preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['orderid']);
    
    $getInvoiceCustomerData = $ct->getInvoiceCustomerData($orderid);
    $result = $getInvoiceCustomerData->fetch_assoc();
    $delivery = $result['delivery'];
    
    $invoiceNumber = str_pad($result['invid'], 6, '0', STR_PAD_LEFT);
    
    $orderNumber = str_pad($result['orderid'], 6, '0', STR_PAD_LEFT);
    
    $invoiceDate = $result['odate'];
    
    $companyName = "Quality Nutrition";
    $companyAddress = "117, Upper Jessore Road, Khulna, Bangladesh";
    $companyPhone = "01612-039399";
    $companyEmail = "qualitynutrition001@gmail.com";
    $companyWebsite = "www.qualitynutritionbd.com";
    
    $customerName = $result['name'];
    $customerAddress = $result['address'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .invoice-box { max-width: 800px; margin: auto; padding: 30px; border: 1px solid #eee; box-shadow: 0 0 10px rgba(0, 0, 0, 0.15); }
        .invoice-box table { width: 100%; line-height: inherit; text-align: left; }
        .invoice-box table td { padding: 5px; vertical-align: top; }
        .invoice-box table tr td:nth-child(4) { text-align: justify; }
        .invoice-box table tr.top table td { padding-bottom: 20px; }
        .invoice-box table tr.information table td { padding-bottom: 40px; }
        .invoice-box table tr.heading td { background: #eee; border-bottom: 1px solid #ddd; font-weight: bold; }
        .invoice-box table tr.details td { padding-bottom: 20px; }
        .invoice-box table tr.item td { border-bottom: 1px solid #eee; }
        .invoice-box table tr.item.last td { border-bottom: none; }
        .invoice-box table tr.total td:nth-child(2) { border-top: 2px solid #eee; font-weight: bold; }
    </style>
</head>
<body>
    
    <div class="invoice-box">
        <table>
            <tr class="top">
                <td colspan="2">
                    <table>
                        <tr>
                            <td>
                                <a href="index.php"><img src="images/qualitynut.jpg" alt="" /></a>
                            </td>
                            <td>
                                <h2><?= $companyName ?></h2>
                                <?= $companyAddress ?><br>
                                <?= $companyPhone ?><br>
                                <?= $companyEmail ?><br>
                                <a href="index.php"><?= $companyWebsite ?></a>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <h2>INV #<?= $invoiceNumber ?></h2>
                                <strong>Order No:</strong><?= $orderNumber ?><br>
                                <strong>Date:</strong> <?= $invoiceDate ?><br>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class="information">
                <td colspan="2">
                    <table>
                        <tr>
                            <td>
                                Bill To:<br>
                                <?= $customerName ?><br>
                                <?= $customerAddress ?>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class="heading">
                <td>No.</td>
                <td>Description</td>
                <td>Unit Price</td>
                <td>Price</td>
            </tr>
            <?php 
            $getInvoiceData = $ct->getInvoiceData($orderid);
            
            if ($getInvoiceData) {
                $i=0; $subtotal = 0; $total = 0;
              while ($result = $getInvoiceData->fetch_assoc()) {
                  $i++;
                  $subtotal += $result["quantity"] * $result["price"];
                  ?>
                <tr class="item">
                    <td><?= $i ?></td>
                    <td><?= $result["productName"] ?> (x<?= $result["quantity"] ?>)</td>
                    <td>&#2547;<?= number_format($result["price"], 2) ?></td>
                    <td>&#2547;<?= number_format($result["quantity"] * $result["price"], 2) ?></td>
                </tr>
            <?php
                  }
                $total = $subtotal + $delivery ;
              } else {
                  echo "<script>window.location = '404.php';</script>";
              } ?>
                
            <tr class="total">
                <td></td>
                <td>Subtotal: &#2547;<?= number_format($subtotal, 2) ?></td>
            </tr>
            <tr class="total">
                <td></td>
                <td>Shipping Fees: &#2547;<?= number_format($delivery, 2) ?></td>
            </tr>
            <tr class="total">
                <td></td>
                <td>Total: &#2547;<?= number_format($total, 2) ?></td>
            </tr>
        </table>
    </div>
</body>
</html>
