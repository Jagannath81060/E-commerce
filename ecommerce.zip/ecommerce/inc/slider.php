<div class="header_bottom">
	<div class="header_bottom_left_images">
		<!-- FlexSlider -->
		<section class="slider">
			<div class="flexslider">
				<ul class="slides">
					<li><img src="images/slider1.jpg" alt="" /></li>
					<li><img src="images/slider2.jpg" alt="" /></li>
					<li><img src="images/slider3.jpg" alt="" /></li>
					<li><img src="images/slider4.jpg" alt="" /></li>
				</ul>
			</div>
		</section>
		<!-- FlexSlider -->
	</div>
	<div class="clear"></div>
</div>
