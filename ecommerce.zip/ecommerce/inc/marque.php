<section class="marque-notice-section">  
    <div class="container media-webkit-center">
        <div class="row">
            <div class="marque-bg text-left media-text-center font12 media-font15 " style="background: rgb(230,240,250);/*#F5F5F5*/; margin:0 0 5px 0;">
                <table class="top-bar-table" style="width:100%">
                    <tbody>
                        <tr>
                            <td class="left-td" style="width: 130px;">
                            <div style="display: inline;"> 
                              <span><i class="fa fa-bullhorn"></i>&nbsp; <span class="" style="font-weight: bold;font-size: 13px;color: #650a0a;">Update Info:</span></span>
                            </div>
                            </td>
                            <td class="middle-td">
                            <div style="">
                                    
                            <style>
                                #top-bar-notice .color {
                                color: #e50505;
                                color: #05154d;
                            }
                            #top-bar-notice a 
                            {
                                padding: 0px 15px;
                                font-size: 13px;
                                font-weight: bold;
                            }
                            </style>
                            <marquee id="top-bar-notice" class="float-left" behavior="scroll" direction="left" height="29" scrolldelay="100" scrollamount="5" onmouseover="this.stop()" onmouseout="this.start()">
                                
                                <a class="color" href="https://qualitynutritionbd.com/products.php?type=1" title="Career." target="_blank" rel="noopener noreferrer">
                                <i class="fa fa-bullhorn color"></i> Feature Products.</a>
                                
                                <a class="color" href="https://qualitynutritionbd.com/products.php?type=2" title="Career." target="_blank" rel="noopener noreferrer">
                                <i class="fa fa-bullhorn color"></i> New Products.</a>
                                
                                <a class="color" href="https://qualitynutritionbd.com/products.php?type=3" title="Career." target="_blank" rel="noopener noreferrer">
                                <i class="fa fa-bullhorn color"></i> Upcoming Products.</a>
                                
                            </marquee>

                            </div>
                          </td>
                          <td class="right-td" style="width: 5px;"></td>
                      </tr>
                  </tbody>
              </table>
            </div>
        </div>
    </div>
</section>