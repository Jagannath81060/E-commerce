<div class="col-sm-12 col-xs-12">
	<marquee onmouseover="javascript:this.stop();" onmouseout="javascript:this.start();" scrolldelay="100" direction="left" scrollamount="3" behavior="scroll" style="width: 100%; height: 30px; color: red; font-size: 20px; margin-top: 10px; background: white;">
            
        <a class="color" href="https://qualitynutritionbd.com/products.php?type=1" title="Career." target="_blank" rel="noopener noreferrer">
        <i class="fa fa-bullhorn color"></i> Feature Products.</a>
        
        <a class="color" href="https://qualitynutritionbd.com/products.php?type=2" title="Career." target="_blank" rel="noopener noreferrer">
        <i class="fa fa-bullhorn color"></i> New Products.</a>
        
        <a class="color" href="https://qualitynutritionbd.com/products.php?type=3" title="Career." target="_blank" rel="noopener noreferrer">
        <i class="fa fa-bullhorn color"></i> Upcoming Products.</a>
        
        <!--<a href="https://qualitynutritionbd.com/products.php?type=1" target="_blank" style="font-size:14pt;cursor:pointer;color:Navy">:: Feature Products. ::</a>-->
        <!--<a href="https://qualitynutritionbd.com/products.php?type=2" target="_blank" style="font-size:14pt;cursor:pointer;color:Navy">:: New Products. ::</a>-->
        <!--<a href="https://qualitynutritionbd.com/products.php?type=3" target="_blank" style="font-size:14pt;cursor:pointer;color:Navy">:: Upcoming Products. ::</a>-->
        
    </marquee>
</div>