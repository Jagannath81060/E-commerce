</div>

<div class="footer">
    <div class="wrapper">
        <div class="section group">
            <div class="col_1_of_4 span_1_of_4 text-center fw-bolder font-monospace">
				<h4>Location</h4>
				<ul>
				<li><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3677.495942848669!2d89.55251407560957!3d22.82113402381491!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39ff91c66a18cd79%3A0x250b5e3b37528d9e!2sQuality%20Nutrition!5e0!3m2!1sen!2sbd!4v1719151469918!5m2!1sen!2sbd" width="125" height="125" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></li>
				</ul>
			</div>
			<div class="col_1_of_4 span_1_of_4 text-center fw-bolder font-monospace">
				<h4>Why buy from us</h4>
					<ul>
					<li class="fw-semibold fst-italic"><a href="about.php">About Us</a></li>
					<li class="fw-semibold fst-italic"><a href="contact.php">Customer Service</a></li>
					<!--<li><a href="#">Privacy Policy</a></li>-->
					<!--<li><a href="contact.php"><span>Site Map</span></a></li>-->
					<!--<li><a href="preview.php"><span>Search Terms</span></a></li>-->
					</ul>
			</div>
			<div class="col_1_of_4 span_1_of_4 text-center fw-bolder font-monospace">
				<h4>My account</h4>
				<ul>
					<li class="fw-semibold fst-italic"><a href="login.php">Sign In</a></li>
					<li class="fw-semibold fst-italic"><a href="cart.php">View Cart</a></li>
					<li class="fw-semibold fst-italic"><a href="wlist.php">My Wishlist</a></li>
					<li class="fw-semibold fst-italic"><a href="orderdetails.php">Track My Order</a></li>
					<!--<li><a href="faq.php">Help</a></li>-->
				</ul>
			</div>
			<div class="col_1_of_4 span_1_of_4 text-center fw-bolder font-monospace">
				<h4>Contact</h4>
				<ul>
					<li><span><a href="tel:01936617062" class="nav-link p-0 text-white font-monospace"></a>+8801936617062</span></li>
					<li><span><a href="tel:01914843572" class="nav-link p-0 text-white font-monospace"></a>+8801914843572</span></li>
					<li><span><a href="tel:01612039399" class="nav-link p-0 text-white font-monospace"></a>+8801612039399</span></li>

				</ul>
			</div>
			
			<!--<div class="social-icons">-->
			<!--	<h4>Follow Us</h4>-->
   <!--             <ul>-->
   <!--                 <li><a href="https://www.facebook.com/profile.php?id=100076217506307" target="_blank" class=" fs-4"><i class="lni lni-facebook-oval fs-4"></i></a></li>-->
   <!--                 <li><a href="#" target="_blank" class=" fs-4"><i class="lni lni-instagram"></i></a></li>-->
   <!--                 <li><a href="mailto:qualitynutrition001@gmail.com" target="_blank" class=" fs-4"><i class="lni lni-google"></i></a></li>-->
   <!--                 <li><a href="mailto:info@qualitynutritionbd.com" target="_blank" class=" fs-4"><i class="lni lni-envelope"></i></a></li>-->
   <!--                 <div class="clear"></div>-->
   <!--             </ul>-->
			<!--</div>-->
			</div>
			<div class="copy_right">
				<p>Copyright &copy; 2020-<?php echo date("Y");?> <a href="https://www.qualitynutritionbd.com">Quality Nutrition.</a>. All Rights Reserved.</p>
		   </div>
        
    </div>
</div>
    <script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
	  			containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
	 		};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
    <link href="css/flexslider.css" rel='stylesheet' type='text/css' />
	  <script defer src="js/jquery.flexslider.js"></script>
	  <script type="text/javascript">
		$(function(){
		  SyntaxHighlighter.all();
		});
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	  </script>
	  
</body>
</html>
