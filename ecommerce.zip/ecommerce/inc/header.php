<?php 
include 'lib/Session.php';
Session::init();
include 'lib/Database.php';
include 'helpers/Format.php';
include 'classes/Product.php';
include 'classes/Cart.php';

spl_autoload_register(function ($class) {
    include_once "classes/".$class.".php";
});
$db = new Database();
$fm = new Format();
$pd = new Product();
$ct = new Cart();
$cat = new Category();
$cmr = new Customer();
?>
<?php
  header("Cache-Control: no-cache, must-revalidate");
  header("Pragma: no-cache");
  header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
  header("Cache-Control: max-age=2592000");
?>

<?php
$search = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $search = $_POST['search'];
}
?>



<!DOCTYPE HTML>
<head>
<title>Quality Nutrition</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="icon" type="image/x-icon" href="images/qualitynut.jpg">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
<link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
<link href="css/menu.css" rel="stylesheet" type="text/css" media="all"/>
<!-- Bootstrap CSS -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap JS (includes Popper.js) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>

<script src="js/jquerymain.js"></script>
<script src="js/script.js" type="text/javascript"></script>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="js/nav.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script> 
<script type="text/javascript" src="js/nav-hover.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script type="text/javascript">
  $(document).ready(function($){
    $('#dc_mega-menu-green').dcMegaMenu({rowItems:'4',speed:'fast',effect:'fade'});
  });
</script>

<style>
#navbarSupportedContent .nav-item .active{
    font-weight:500;
    color: #f61107;
    font-family: Georgia, serif;
    
    background: #16c91b;
}

#navbarDropdown{
    /*color: #08f7bb;*/
    color: #70A950;
    font-weight:600;
    text-shadow:rgba(0, 0, 0, 0.3) 0px 1px 1px;
    font-size:14px;
    letter-spacing:-0.4px;
    line-height:1.4em;
    text-transform:capitalize;
    text-align:center;
}



       

       .search{
       position: relative;
       box-shadow: 0 0 40px rgba(51, 51, 51, .1);
       width: 80%;
       margin-top: 100px;
         
       }

       .search input{

        height: 60px;
        text-indent: 25px;
        border: 2px solid #d6d4d4;
        width: 100%;


       }


       .search input:focus{

        box-shadow: none;
        border: 2px solid blue;


       }

       .search .fa-search{

        position: absolute;
        top: 20px;
        left: 16px;

       }

       .search button{

        position: absolute;
        top: 5px;
        right: 5px;
        height: 50px;
        width: 110px;
        background: blue;

       }

      
</style>

</head>
<body>
    <div class="wrap">
    <!-- Alert Section -->
    <div class="alert alert-success text-center mb-0" role="alert" style="background: #f61107; color: #fff; font-size: 14px; border: 0; font-weight: 500; letter-spacing: 1px; text-transform: uppercase;">
        Delivery all over Bangladesh
    </div>
    
    
    <!-- Top Menu Main Section -->
    <section class="top-menu-main">
        <div class="container-fluid">
            <div class="container">
                <!-- Navbar Start -->
                <nav class="navbar navbar-expand-lg navbar-light">
                    <!-- Toggler/collapsible Button -->
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
    
                    <!-- Collapse wrapper for both left and right sections -->
                    <div class="collapse navbar-collapse" id="mainNavbar">
                        <!-- Left Section -->
                        <ul class="navbar-nav me-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="tel:01612039399">
                                    <i class="fa fa-phone text-danger"></i> 
                                    <span class="text-primary fw-bolder">01612039399 </span>
                                </a>
                        </li>
                        </ul>
                        <!-- Right Section -->
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="https://www.facebook.com/profile.php?id=100076217506307">
                                    <i class="fab fa-facebook-f" style="color:blue"></i>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="https://www.youtube.com/@qualitynutrition">
                                    <i class="fab fa-youtube" style="color:red"></i>
                                </a>
                            </li>
                            <li class="nav-item">
                                <?php 
                                    $login = Session::get("cuslogin");
                                    if ($login == false) {
                                ?>
                                    <a class="nav-link" href="login.php">Sign In</a>
                                <?php
                                    } else {
                                ?>
                                   <button class="bg-primary px-2 py-1 rounded"> <a class="nav-link text-white fw-bolder" href="?cid=<?php Session::get('cmrId'); ?>">Sign Out</a> </button> 
                                <?php
                                    }
                                ?>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- Navbar End -->
            </div>
        </div>
    </section>
    
    
    
    
      <!-- Header Section -->
    <div class="header_top">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-12">
                    <div class="logo">
                        <a href="index.php">
                            <img src="images/qualitynut.jpg" alt="Logo" class="img-fluid" />
                        </a>
                    </div>
                </div>
                <div class="col-md-8 col-sm-12">
                    <div class="d-flex justify-content-center align-items-center h-100">
                        <form action="search.php" method="post" class="w-100">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control" placeholder="Search for Products">
                                <button class="btn btn-primary" type="submit" name="submit" value="SEARCH">SEARCH</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="menu">
      <ul id="dc_mega-menu-green" class="dc_mm-green">
        <li><a href="index.php">Home</a></li>   
        <li><a href="#">Products</a>
            <ul>
                <li> <a href="products.php?type=1">Feature Products</a></li>
                <li> <a href="products.php?type=2">New Products</a></li>
                <li><a href="products.php?type=3">Upcoming Products</a></li>
                <li><a href="allproducts.php">All Products</a></li>
            </ul>
        </li>
        <?php 
          $chkCart = $ct->checkCartItem();
          if ($chkCart) {
              ?>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="payment.php">Payment</a></li>
          <?php
          }
           ?>
           <?php
          $cmrId = Session::get("cmrId");
          $chkOrder = $ct->checkOrder($cmrId);
          if ($chkOrder) {
              ?>        
            <li><a href="orderdetails.php">Order</a></li>
          <?php
          }
           ?>
        
    <?php 
    $login = Session::get("cuslogin");
    if ($login == true) {
        ?>
      <li><a href="profile.php">Profile</a></li>
    <?php
    }
     ?>
        
        <?php 
            $checkWlist = $pd->getWlistData($cmrId);
            if ($checkWlist) {
        ?>
        <li><a href="wlist.php">Wishlist</a></li>
        <?php
                                } ?>
        <li><a href="about.php">About Us</a> </li>
        <li><a href="contact.php">Contact</a> </li>
        <div class="clear"></div>
      </ul>
    </div>