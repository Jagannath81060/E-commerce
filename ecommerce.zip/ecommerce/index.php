<?php include 'inc/header.php'; ?>
<?php include 'inc/marquee.php'; ?>
<?php include 'inc/slider.php'; ?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>Feature Products</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
	      <div class="section group">
	      	<?php 
              $getFpd = $pd->getFeaturedProduct();
              if ($getFpd) {
                  while ($result = $getFpd->fetch_assoc()) {
                      ?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="details.php?proId=<?= $result['productId']; ?>"><img src="admin/<?= $result['image']; ?>" alt="" /></a>
					 <h2><?= $result['productName']; ?></h2>
					 <p><span class="price"><?php if($result['discount']>0) { ?><span class="price"><del>&#2547; <?= $result['price']; ?></del></span><?php }?> &#2547;<?= $productPrice=$result['discount']>0? $result['price']-$result['discount']:$result['price']; ?></span></p>
				     <div class="button"><span><a href="details.php?proId=<?= $result['productId']; ?>" class="details">Details</a></span></div>
				</div>
				<?php
                  }
              } ?>
			</div>
			<div class="content_top">
    		<div class="heading">
    		<h3>New Products</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
	      <div class="section group">
	      	<?php 
              $getNpd = $pd->getNewProduct();
              if ($getNpd) {
                  while ($result = $getNpd->fetch_assoc()) {
                      ?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="details.php?proId=<?= $result['productId']; ?>"><img src="admin/<?= $result['image']; ?>" alt="" /></a>
					 <h2><?= $result['productName']; ?></h2>
					 <p><span class="price"><?php if($result['discount']>0) { ?><span class="price"><del>&#2547; <?= $result['price']; ?></del></span><?php }?> &#2547;<?= $productPrice=$result['discount']>0? $result['price']-$result['discount']:$result['price']; ?></span></p>
				     <div class="button"><span><a href="details.php?proId=<?= $result['productId']; ?>" class="details">Details</a></span></div>
				</div>
				<?php
                  }
              } ?>
			</div>
			<div class="content_bottom">
    		<div class="heading">
    		<h3>Upcoming Products</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
			<div class="section group">
				<?php 
              $getUpd = $pd->getUpcomingProduct();
              if ($getUpd) {
                  while ($result = $getUpd->fetch_assoc()) {
                      ?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="details.php?proId=<?= $result['productId']; ?>"><img src="admin/<?= $result['image']; ?>" alt="" /></a>
					 <h2><?= $result['productName']; ?></h2>
					 <p><span class="price"><?php if($result['discount']>0) { ?><span class="price"><del>&#2547; <?= $result['price']; ?></del></span><?php }?> &#2547;<?= $productPrice=$result['discount']>0? $result['price']-$result['discount']:$result['price']; ?></span></p>
				     <div class="button"><span><a href="details.php?proId=<?= $result['productId']; ?>" class="details">Details</a></span></div>
				</div>
				
				<?php
                  }
              } ?>
				
			</div>
    </div>
    <script>
        function formatPrice() {
            const input = document.getElementById('price');
            let value = input.value;

            // Remove previous BDT if present
            if (value.includes(" BDT")) {
                value = value.replace(" BDT", "");
            }

            // Append BDT
            if (value) {
                input.value = value + " BDT";
            }
        }
    </script>

<?php include 'inc/footer.php'; ?>
 </div>
