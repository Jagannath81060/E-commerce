<?php include 'inc/header.php'; ?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$login = Session::get("cuslogin");
if ($login == false) {
    header("Location:login.php");
}
?>
<?php 
if (isset($_GET['orderid']) && $_GET['orderid'] == 'online') {
    $cmrId = Session::get("cmrId");
    $invqty = Session::get("invqty");
    
    $insertOrder = $ct->orderProduct($cmrId);
    

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $method = $_POST['method'];
    //print_r($method);
    $transaction = $_POST['transaction_id'];
    //print_r($transaction);
    $pdate = $_POST['transaction_date'];
    //print_r($pdate);
    }
    //var_dump($method);var_dump($transaction);var_dump($pdate); exit;
    
    $amount= Session::get("gTotal");
    $delivery= Session::get("delivery");
    
    $pstatus=1;
    $odate= date("Y-m-d H:i:s");
    $ostatus=1;
    
    $paymentOrder = $ct->orderPaymentInfo($cmrId, $invqty, $method, $amount, $delivery, $transaction, $pdate, $pstatus, $odate, $ostatus);
    
    $delData = $ct->delCustomerCart();
    header("Location:success.php");
}
?>
<style>
.mb-60 {
    margin-bottom: 60px;
}
.services-inner {
    border: 2px solid #48c7ec;
    margin-left: 35px;
    transition: .3s;
}
.our-services-img {
    float: left;
    margin-left: -25px;
    margin-right: 1px;
    margin-top: 10px;
}
.our-services-img2 {
    float: left;
    margin-left: -36px;
    margin-right: 22px;
    margin-top: 28px;
}
.our-services-text {
    padding-right: 10px;
}
.our-services-text {
    overflow: hidden;
    padding: 28px 0 25px;
}
.our-services-text h4 {
    color: #222222;
    font-size: 18px;
    font-weight: 700;
    letter-spacing: 1px;
    margin-bottom: 8px;
    padding-bottom: 10px;
    position: relative;
    text-transform: uppercase;
}
.our-services-text h4::before {
    background: #ec6d48 none repeat scroll 0 0;
    bottom: 0;
    content: "";
    height: 1px;
    position: absolute;
    width: 35px;
}
.our-services-wrapper:hover .services-inner {
    background: #fff none repeat scroll 0 0;
    border: 2px solid transparent;
    box-shadow: 0px 5px 10px 0px rgba(0, 0, 0, 0.2);
}
.our-services-text p {
    margin-bottom: 0;
}
p {
    font-size: 14px;
    font-weight: 400;
    line-height: 26px;
    //color: #666;
    margin-bottom: 15px;
}
.text-token {
	background: #f99;
	overflow: hidden;
	border-top-right-radius: 5px;
	border-bottom-left-radius: 5px;
}

#bKash_button {
  background-image: url(../resources/image/Payment-logo-English_2.png);
  background-repeat: no-repeat;
  background-position: 50% 50%;
  /* put the height and width of your image here */
  height: 50px;
  width: 150px;
  border: none;
  background-size: contain;
  background-color: transparent;
  
}

.ui-widget-overlay {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 1050;
    display: none;
    overflow: hidden;
    outline: 0;
}
</style>

<style>
.databox {
    height: 200px;
    width: 50%;
    position: absolute;
     margin-left:500px
}

#header { color: #337ab7; }

#table { 
    border-spacing: 10px;
    border-collapse: separate;
}


#table td{
	min-width: 145px;
}

.caption{
	border-top: 1px solid gray;
	text-align:justify;
}

</style>
<style type="text/css">
.division{width:50%; float:left;}
.tblone{width: 95%; margin-right:15px; border:2px solid #ddd;}
.tblone tr td{text-align: justify;}
.tbltwo{float:right; text-align:left; width:40%; border:2px solid #ddd; margin-right:14px; margin-top: -4px; margin-right: 38px;}
.tbltwo tr td{text-align:justify; padding: 5px 10px;}
.ordernow{}
.ordernow a{width:200px; margin:20px auto 0; text-align: center; padding:5px; font-size:30px; display: block; background: #3C3B40; color: white; border-radius: 3px;}
</style>
 
<div class="main">
	<div class="content">
		<div class="section group">
			<div class="division">
				<table class="tblone">
					<tr>
						<th>No</th>
						<th>Product</th>								
						<th>Price</th>
						<th>Quantity</th>
						<th>Total</th>								
					</tr>
					<?php 
                    $getPro = $ct->getCartProduct();
                    if ($getPro) {
                        $i=0;
                        $sum = 0;
                        $qty = 0;
                        while ($result = $getPro->fetch_assoc()) {
                            $i++; ?>
					<tr>
						<td><?= $i; ?></td>
						<td><?= $result['productName']; ?></td>								
						<td>&#2547;<?= $result['price'].".00"; ?></td>
						<td><?= $result['quantity'].".00"; ?></td>								
						<td>&#2547;<?= $total = $result['price'] * $result['quantity']; number_format($total).".00"; ?></td>								
					</tr>
					<?= $qty = $qty + $result['quantity']; $sum = $sum + $total; ?>
					<?php
                        }
                    } ?>
				</table>
				
				<div class="division">
                    <div class="select_delivery_Method">
                        <h2 class="my-3 pt-2 text-center" style="line-height: 10px">Delivery Location</h2>
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="deliveryCharge_wrapper">
                                    <ul class="list-unstyled">
                                        <li><label><input class="mr-1" name="optradio" type="radio" value="1" checked="">Inside Khulna</label></li>
                                        <br>
                                        <li><label><input class="mr-1" name="optradio" type="radio" value="2">Outside Khulna</label></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
				<table class="tbltwo">
					<tr>								
						<td>Sub Total</td>
						<td>:</td>
						<td>&#2547;<?= number_format($sum).".00"; ?></td>								
					</tr>
					
					<tr>
						<td>Delivery Charge</td>
						<td>:</td>
						<td><span id="delivery"></span></td>
					</tr>
					<tr>
						<td>Grand Total</td>
						<td>:</td>
						<td><span id="grandtotal"></span></td>
					</tr>
					<tr>								
						<td>Quantity</td>
						<td>:</td>
						<td><?= $qty; ?></td>								
					</tr>
			   </table>
            </div>
            <div class="division">
			
			<form action="" method="post">	
			<table class="tblone">
				<tr>
					<td colspan="3" style="text-align: center;"><h2>Payment Details</h2></td>					
				</tr>
				<tr>
					<td width="20%">Payment Method</td>
					<td width="5%">:</td>
					<td>
					    <select name="method" id="method" class="form-control form-control-sm">
					        <option value="0">Select Payment Method</option>
                            <option value="1">Bank Payment</option>
                            <option value="2">bKash</option>
                            <option value="3">Nagad</option>
                        </select>
                    </td>
				</tr>
				<tr>
					<td>Amount Paid</td>
					<td>:</td>
					<!--<input type="text" name="amount" id="amount" class="form-control form-control-sm" value="">-->
					<td><span id="payment"></span></td>
				</tr>
				<tr>
					<td>Transaction ID</td>
					<td>:</td>
					<td><input type="text" placeholder="Txn ID / bKash Txn ID / Nagad Txn ID" name="transaction_id" class="form-control form-control-sm"  value=""> </td>
				</tr>
				<tr>
					<td>Transaction Date</td>
					<td>:</td>
					<td><input type="date" name="transaction_date" id="transaction_date"  class="form-control form-control-sm" value="<?php $d=date("Y-m-d H:i:s"); echo $d; ?>"></td>
				</tr>
				
			</table>
			
			<!-- Hidden Input Fields -->
            <input type="hidden" name="method" value="$_POST['method']">
            <input type="hidden" name="transaction_id" value="$_POST['transaction_id'];">
            <input type="hidden" name="transaction_date" value="$_POST['transaction_date'];">
			
			</form>
	
			</div>
		</div>
	<div class="content">
		<div class="section group">
			<div class="division">
				<?php 
            $id = Session::get("cmrId");
            $getData = $cmr->getCustomerData($id);
            if ($getData) {
                while ($result = $getData->fetch_assoc()) {
                    ?>
			<table class="tblone">
				<tr>
					<td colspan="3" style="text-align: center;"><h2>Your Profile Details</h2></td>					
				</tr>
				<tr>
					<td width="20%">Name</td>
					<td width="5%">:</td>
					<td><?= $result['name']; ?></td>
				</tr>
				<tr>
					<td>Phone</td>
					<td>:</td>
					<td><?= $result['phone']; ?></td>
				</tr>
				<tr>
					<td>Email</td>
					<td>:</td>
					<td><?= $result['email']; ?></td>
				</tr>
				<tr>
					<td>Address</td>
					<td>:</td>
					<td><?= $result['address']; ?></td>
				</tr>
				<tr>
					<td>City</td>
					<td>:</td>
					<td><?= $result['city']; ?></td>
				</tr>
				<tr>
					<td>Zip Code</td>
					<td>:</td>
					<td><?= $result['zip']; ?></td>
				</tr>
				<tr>
					<td>Country</td>
					<td>:</td>
					<td><?= $result['country']; ?></td>
				</tr>
				<tr>
					
					<td colspan="3" style="text-align: center; font-size: 22px;"><a style="color: green;" href="editprofile.php">Update Details</a></td>
					
				</tr>				
			</table>
			<?php
                }
            } ?>	
		</div>
	</div>
		
</div>
</div>
		<div class="ordernow">
			<a href="?orderid=online">Order</a>
		</div>
	</div>
	<script type="text/javascript">
        $(document).ready(function(){
           $("input[type='radio']").click(function() {
               var radioValue = $("input[name='optradio']:checked").val();
        
               // this block is for Inside khulna ( id --> 1)
               if(radioValue === '1'){

                   $('#insidekhulna').show();
                   $('#outsidekhulna').hide();
                   
                    $('#delivery').html("&#2547;<?php $delivery=60; Session::set("delivery", $delivery); echo number_format($delivery).".00"; ?>");
                    $('#grandtotal').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
                    $('#payment').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
               }
        
               else if(radioValue === '2'){
        
                    $('#insidekhulna').hide();
                    $('#outsidekhulna').show();
                   
                    $('#delivery').html("&#2547;<?php $delivery=150; Session::set("delivery", $delivery); echo number_format($delivery).".00"; ?>");
                    $('#grandtotal').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
                    $('#payment').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
                    
        
               }
               
           });
        
           $('#outsidekhulna').hide();
           var radioValue = $("input[name='optradio']:checked").val();
        
            // for 1 inside khulna
           if(radioValue === '1'){
                $('#insidekhulna').show();
                $('#outsidekhulna').hide();
                $('#delivery').html("&#2547;<?php $delivery=60; Session::set("delivery", $delivery); echo number_format($delivery).".00"; ?>");
                $('#grandtotal').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
                $('#payment').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
               
           }
            // for 2 outside khulna
           else if(radioValue === '2'){
                $('#insidekhulna').hide();
                $('#outsidekhulna').show();
                $('#delivery').html("&#2547;<?php $delivery=150; Session::set("delivery", $delivery); echo number_format($delivery).".00"; ?>");
                $('#grandtotal').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
                $('#payment').html("&#2547;<?php $gTotal = $sum+$delivery; Session::set("gTotal", $gTotal); echo number_format($gTotal).".00"; ?>");
           }
        });
    </script>
	
	    <div class="row justify-content-center mb-2" >
        	<div class="col-md-6" style="font-size:14px;">
        		<p class='text-center '>
        		    <br>Click button below to view instrunctions. <br>
				    <br><button id="bKashinst_btn" class='btn btn-info' >bKash</button>&ensp; &emsp;<button id="nagadinst_btn" class='btn btn-info' >Nagad</button><br>
				</p>
			</div>
		</div>
	    <!-- ============================================================== -->
        <!-- bKash Payment Instructions  -->
        <!-- ============================================================== -->

        <div id='bKashinst' > 
        <div class="row justify-content-center payment-instruction"  data-aos="fade-down">
        	<div class="col-lg-11 col-md-11 border rounded shadow p-2 bg-light" data-aos="fade-down">
 
				<div class="row">
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
								 <div class='text-token'><b><font size=+3> &nbsp;1&nbsp; </font></b></div>
								</div>
								<div class="our-services-text ">
									<br><br><br>
									<center><b>Dial *247#</b/center>
									<br><br><br><br>
								</div>
							</div>
						</div>
					</div>
			
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
								<div class='text-token'><b><font size=+3> &nbsp;2&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Select Option <strong>4</strong> </center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<b>bKash</b><br>
											1. Send Money<br>
											2. Send Money to Non-bKash User<br>
											3. Mobile Recharge<br>
											<b>4. Payment</b><br>
											5. Cash Out<br>
											6. Pay Bill<br>
											7. Microfinance<br>
											8. Download bKash App<br>
											9. My bKash<br>
											10. Reset PIN
										</div>
									</div>
									<div class="border border-info text-white bg-dark">
									 	<p class="text-center">4</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img ">
								<div class='text-token'><b><font size=+3> &nbsp;3&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Enter Merchant bKash Account No: </center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 py-4">
											Enter Merchant bKash Account No:
										</div>
									</div>
									<div class="border border-info text-white bg-dark">
									 	<p class="text-center">01936617062</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
								<div class='text-token'><b><font size=+3> &nbsp;4&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Enter Amount: </center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 py-4">
											<strong>Enter Amount:</strong>
										</div>
									</div>
									
									
									<div class="border border-info text-white bg-dark">
										<p class="text-center">500</p>
									</div>
									
								</div>
							</div>
						</div>
					</div>
				</div>
			
				<div class="row">
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
								<div class='text-token'><b><font size=+3> &nbsp;5&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Enter your Customer ID or Username in Reference </center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 py-4">
											<strong>Enter Reference:</strong>
										</div>
									</div>
									<div class="border border-info text-white bg-dark">
									 	<p class="text-center">266944</p>
									</div>
								</div>
							</div>
						</div>
					</div>
			
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
								<div class='text-token'><b><font size=+3> &nbsp;6&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Enter Counter Number </center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 py-4">
											<strong>Enter Counter No:</strong>
										</div>
									</div>

									<div class="border border-info text-white bg-dark">
									 	<p class="text-center">1</p>
									</div>
								</div>
							</div>
						</div>
					</div>
			
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
									<div class='text-token'><b><font size=+3> &nbsp;7&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Enter PIN number to complete payment</center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											Payment to: <strong>01936617062</strong> <br> 
											Amount: <strong>
											
								          		
								          		
								          			500
								          		
								          	
							          	</strong> BDT. <br> 
											Reference: <strong>266944</strong> <br>Counter:1 <br>Enter PIN to continue:<br>
										</div>
									</div>
									
									<div class="border border-info text-white bg-dark">
										 	<p class="text-center">XXXXX</p>
									</div>
								</div>
							</div>
						</div>
					</div>
			
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
									<div class='text-token'><b><font size=+3> &nbsp;8&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; You'll get confirmation message after successful payment</center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											Payment to: <b>01936617062</b> successful. Fee Tk 0, Balance Tk. 0000, TrxID 5HH81D8K6A at 01/01/2018 00:00<br><br>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			
			</div>
	    </div>
    </div>
    
    <!-- ============================================================== -->
        <!-- Nagad Payment Instructions  -->
        <!-- ============================================================== -->

        <div id='nagadinst' > 
        <div class="row justify-content-center payment-instruction"  data-aos="fade-down">
        	<div class="col-lg-11 col-md-11 border rounded shadow p-2 bg-light" data-aos="fade-down">
 
				<div class="row">
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
								 <div class='text-token'><b><font size=+3> &nbsp;1&nbsp; </font></b></div>
								</div>
								<div class="our-services-text ">
									<br><br><br>
									<center><b>Dial *167#</b/center>
									<br><br><br><br>
								</div>
							</div>
						</div>
					</div>
			
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
								<div class='text-token'><b><font size=+3> &nbsp;2&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Select Option <strong>4</strong> </center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<b>Nagad</b><br>
											1. Cash Out<br>
											2. Send Money<br>
											3. Mobile Recharge<br>
											<b>4. Payment<br></b>
											5. Bill Pay<br>
											6. EMI Payment<br>
											7. My Nagad<br>
											8. PIN Reset<br>
										</div>
									</div>
									<div class="border border-info text-white bg-dark">
									 	<p class="text-center">4</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img ">
								<div class='text-token'><b><font size=+3> &nbsp;3&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Enter Merchant Nagad Number: </center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 py-4">
											Merchant A/C Number:
										</div>
									</div>
									<div class="border border-info text-white bg-dark">
									 	<p class="text-center">01936617062</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
								<div class='text-token'><b><font size=+3> &nbsp;4&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Enter Amount: </center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 py-4">
											<strong>Enter Amount:</strong>
										</div>
									</div>
									
									
									<div class="border border-info text-white bg-dark">
										<p class="text-center">500</p>
									</div>
									
								</div>
							</div>
						</div>
					</div>
				</div>
			
				<div class="row">
					
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
								<div class='text-token'><b><font size=+3> &nbsp;6&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Enter Counter Number </center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 py-4">
											<strong>Enter Counter No:</strong>
										</div>
									</div>

									<div class="border border-info text-white bg-dark">
									 	<p class="text-center">1</p>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
								<div class='text-token'><b><font size=+3> &nbsp;5&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Enter your customer id or username in reference </center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12 py-4">
											<strong>Enter Reference:</strong>
										</div>
									</div>
									<div class="border border-info text-white bg-dark">
									 	<p class="text-center">266944</p>
									</div>
								</div>
							</div>
						</div>
					</div>
			
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
									<div class='text-token'><b><font size=+3> &nbsp;7&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; Enter PIN number to complete payment</center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											Payment to: <strong>01936617062</strong> <br> 
											Amount: <strong>
											
								          		
								          		
								          			500
								          		
								          	
							          	</strong> BDT. <br> 
										Counter:1 <br>Reference: <strong>266944</strong> <br>Enter PIN to continue:<br>
										</div>
									</div>
									
									<div class="border border-info text-white bg-dark">
										 	<p class="text-center">XXXXX</p>
									</div>
								</div>
							</div>
						</div>
					</div>
			
					<div class="col-lg-3 col-sm-6 h-100" data-aos="zoom-in">
						<div class="our-services-wrapper mb-60">
							<div class="services-inner">
								<div class="our-services-img">
									<div class='text-token'><b><font size=+3> &nbsp;8&nbsp; </font></b></div>
								</div>
								<div class="our-services-text px-2">
									<div class="row">
										<div class="col-md-12 border mb-2">
											<center><i class="fas fa-info-circle text-info"></i>&nbsp; You'll get confirmation message after successful payment</center>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											Payment to: <b>01936617062</b> successful. Fee Tk 0, Balance Tk. 0000, TrxID 5HH81D8K6A at 01/01/2018 00:00<br><br>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			
			</div>
	    </div>
    </div>
    
    		
		<!-- Modal -->
		<div class="modal fade" id="modal-dialog" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="z-index:51000; ">
		  <div class="modal-dialog modal-dialog-centered" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h4 class="modal-title" id="exampleModalCenterTitle">Alert</h4>
		      </div>
		      <div class="modal-body">
		        <p class="input-group text-center" id="alertMsg"> </p>
		        <p class="input-group text-center text-danger" id="errorMsg"> </p>
		      </div>
		      <div class="modal-footer " id="modal-close-btn">
		        
		      </div>
		    </div>
		  </div>
		</div>

        <script type="text/javascript">
        
        $( document ).ready(function() {
          	$('#bKashinst').hide();
          	$('#nagadinst').hide();
        });
        $( "#bKashinst_btn" ).click(function() {
          	$('#bKashinst').show();
          	$('#nagadinst').hide();
        });
        $( "#nagadinst_btn" ).click(function() {
          	$('#nagadinst').show();	
          	$('#bKashinst').hide();
        });
        
        var url = 'null';
        var btn='';
                function sleep(milliseconds) {
                	  var start = new Date().getTime();
                	  for (var i = 0; i < 1e7; i++) {
                	    if ((new Date().getTime() - start) > milliseconds){
                	      break;
                	    }
                	  }
                	}
                
                
                $(document).ready(function(){
                	
        			
                    var paymentConfig= {
                    createCheckoutURL: "/api/bkashCreatePayment",
                    executeCheckoutURL: "/api/bkashExecutePayment",
                    };
                    
                    var payAmount=document.getElementById("amount1").value;
                    //console.log(payAmount);
                    var paymentRequest;
                   paymentRequest = { "amount": payAmount, "intent":"sale" };
                   //console.log(paymentRequest);
                    bKash.init({
                        paymentMode: 'checkout',
                        paymentRequest: paymentRequest,
                        createRequest: function (request) {
                            //console.log('=> createRequest (request) :: ');
                            console.log(request);
                            $.ajax({
                                url: paymentConfig.createCheckoutURL,
                                data: {"amount": $("#amount1").val()},
                                type: 'GET',
                                contentType: 'application/json',
                                success: function (data) {
                                    
                                    console.log(JSON.parse(data).paymentID);
                                    data = JSON.parse(data);
                                    if (data && data.paymentID != null) {
                                        paymentID = data.paymentID;
                                        bKash.create().onSuccess(data);
                                        console.log('createRequest =>  ..'+JSON.stringify(data));
                                    } else {
                                    	/*alert("Sorry Something went wrong,Please try agian Later");*/
                                    	//$( "#modal-dialog" ).modal();
                                    	$("#alertMsg").text("Sorry Something went wrong,Please try agian Later");
                                    	$( "#modal-dialog" ).modal({
                                            backdrop: 'static',
                                            keyboard: false,
                                            show: true // added property here
                                        });
                                    	
                                        bKash.create().onError();
                                        
                                        
                                    }
                                },
                                error: function () {
                                	/*alert("Your Bkash Payment is faild to Create,Please try agian Later");*/
                                	$( "#modal-dialog" ).modal();
                                	$("#alertMsg").text("Your Bkash Payment is faild to Create,Please try agian Later");
                                	$( "#modal-dialog" ).modal({
                                        backdrop: 'static',
                                        keyboard: false,
                                        show: true // added property here
                                    });
                                    bKash.create().onError();
                                    
                                    
                                     
                                }
                            });
                        },
                        executeRequestOnAuthorization: function () {
                            console.log('=> executeRequestOnAuthorization');
                            $.ajax({
                                url: paymentConfig.executeCheckoutURL,
                                data: {"amount": $("#amount1").val()},
                                type: 'GET',
                                contentType: 'application/json',
                                success: function (data) {
                                    //console.log('got data from execute  ..');
                                  //  console.log('data ::=>');
                                    //console.log(JSON.stringify(data));
                                    data = JSON.parse(data);
                                    if (data && data.paymentID != null) {
                                    	/*alert("SUCCCESS !! Your bKash Payment is Successful");*/
                                    	if(!url){
                                    		//console.log("url : "+url);
                                    		var urlMsg = "&msg=Your Bkash Payment is Successful of "+$("#amount1").val()+" Tk";/* data-dismiss="modal" */
                                    		btn = '<a href="'+url+urlMsg+'"  aria-hidden="true" class="btn border-primary w-100">OK</a>'
                                    		//window.location.href = url+"&msg=Your Bkash Payment is Successful of "+$("#amount1").val()+" Tk";
                                    		
                                    	}else
                                      		//window.location.href = "/customer/customerhistory";//your success page
                                    		btn = '<a href="/customer/customerhistory"  aria-hidden="true" class="btn border-primary w-100">OK</a>'
                                      		
                               			$("#modal-close-btn").append(btn);
                                   		$("#alertMsg").text("SUCCCESS !! Your Bkash Payment is Successful");
                                   		$( "#modal-dialog" ).modal({
                                            backdrop: 'static',
                                            keyboard: false,
                                            show: true // added property here
                                        });
                                    } else {
                                    	/*"Sorry !! "+data.errorMs*/
                                    	
                                    	$("#alertMsg").text("bKash payment has failed !");
                                    	$("#errorMsg").text(data.errorMsg);
                                        bKash.execute().onError();
                                        if(!url){
                                    		var urlMsg = url+"&msg= Sorry !! "+data.errorMsg;/* data-dismiss="modal" */
                                    		btn = '<a href="'+urlMsg+'" aria-hidden="true" class="btn border-primary w-100">OK</a>'
                                    		//window.location.href = url+"&msg= Sorry !! "+data.errorMsg;
                                    		
                                    	}else
                                    		btn = '<a href="/customer/bkashApi"  aria-hidden="true" class="btn border-primary w-100">OK</a>'
                                    		
                                    		
                                   		$("#modal-close-btn").append(btn);
                                        $( "#modal-dialog" ).modal({
                                            backdrop: 'static',
                                            keyboard: false,
                                            show: true // added property here
                                        });
                                        
                                    }
                                },
                                error: function () {
                                    bKash.execute().onError();
                                }
                            });
                        },
                        onClose : function () {
        
                        	location.reload();
        
                        }
                    });
                });
        </script>
<?php include 'inc/footer.php'; ?>
</div>

