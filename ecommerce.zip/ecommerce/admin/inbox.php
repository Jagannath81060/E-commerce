<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php
$filepath = realpath(dirname(__FILE__));
include_once($filepath.'/../classes/Cart.php');
$ct = new Cart();
$fm = new Format();
?>
<?php

if (isset($_GET['shiftid'])) {
    $cmrId 	= $_GET['shiftid'];
    $invid 	= $_GET['invid'];
    $oid 	= $_GET['oid'];

    $shift = $ct->orderStatus($cmrId, $invid, $oid);
}

if (isset($_GET['shiftid'])) {
    $cmrId 	= $_GET['shiftid'];
    $invid 	= $_GET['invid'];
    $oid 	= $_GET['oid'];

    $shift = $ct->paymentStatus($cmrId, $invid, $oid);
}

if (isset($_GET['delproid'])) {
    $id 	= $_GET['delproid'];
    $time 	= $_GET['time'];
    $price 	= $_GET['price'];

    $delOrder = $ct->delProductShifted($id, $time, $price);
}

?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Inbox</h2>
                <?php
                 if (isset($shift)) {
                     echo $shift;
                 }
    if (isset($delOrder)) {
        echo $delOrder;
    }
  ?>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th style="text-align:center;">No.</th>
							<th style="text-align:center;">Invoice<br>No.</th>
							<th style="text-align:center;">Invoice<br>Date</th>
							<th style="text-align:center;">Order<br>ID</th>
							<th style="text-align:center;">Customer<br>ID</th>
							<th style="text-align:center;">Quantity</th>
							<th style="text-align:center;">Price</th>
							<th style="text-align:center;">Invoice<br>Details</th>
							<th style="text-align:center;">Payment<br>Status</th>
							<th style="text-align:center;">Order<br>Status</th>
							<th style="text-align:center;">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php

                            $getAllInvoice = $ct->getAllInvoice();
                            if ($getAllInvoice) {
                                $i=0;
                                while ($result = $getAllInvoice->fetch_assoc()) {
                                    $i++; ?>
                                    <?php
                                    $invoiceNumber = str_pad($result['invid'], 6, '0', STR_PAD_LEFT);
                                    
                                    $orderNumber = str_pad($result['oid'], 6, '0', STR_PAD_LEFT);
                                    ?>
						<tr class="odd gradeX">
						    <td style="text-align:center;"><?= $i ?></td>
						    <td style="text-align:center;"><?= $invoiceNumber ?></td>
						    <td style="text-align:center;"><?= $fm->formatDate($result['odate']) ?></td>
							<td style="text-align:center;"><?= $orderNumber ?></td>
							<td style="text-align:center;"><a href="../profile.php" target="_blank"><?= $result['cmrId'] ?></a></td>
							<td style="text-align:center;"><?= $result['invqty'] ?></td>
							<td style="text-align:center;">&#2547;<?= number_format($result['amount']).".00" ?></td>
							<td style="text-align:center;"><a href="../invoice.php?orderid=<?= $result['oid'] ?>" target="_blank">View</a></td>
							<?php if ($result['pstatus'] == '0') {
                                    ?>
							    <td style="text-align:center;"><a href="paymentstatus.php?shiftid=<?= $result['cmrId'] ?>&invid=<?= $result['invid'] ?>&orderid=<?= $result['oid'] ?>">Not Paid</a></td>
                                <?php
                                } elseif ($result['pstatus'] == '1') {
                                    ?> 
                                <td style="text-align:center;"><a href="paymentstatus.php?shiftid=<?= $result['cmrId'] ?>&invid=<?= $result['invid'] ?>&orderid=<?= $result['oid'] ?>">Offline Paid</a></td>
                                <?php
                                } elseif ($result['pstatus'] == '2') {
                                    ?> 
                                <td style="text-align:center;"><a href="paymentstatus.php?shiftid=<?= $result['cmrId'] ?>&invid=<?= $result['invid'] ?>&orderid=<?= $result['oid'] ?>">Online Paid</a></td>
                                <?php
                                } else {
                                    ?>
							<?php
                                } ?>
							<?php if ($result['ostatus'] == '0') {
                                    ?>
							    <td style="text-align:center;"><a href="paymentstatus.php?shiftid=<?= $result['cmrId'] ?>&invid=<?= $result['invid'] ?>&orderid=<?= $result['oid'] ?>">Not Placed</a></td>
                                <?php
                                } elseif ($result['ostatus'] == '1') {
                                    ?> 
                                <td style="text-align:center;"><a href="paymentstatus.php?shiftid=<?= $result['cmrId'] ?>&invid=<?= $result['invid'] ?>&orderid=<?= $result['oid'] ?>">Placed</a></td>
                                <?php
                                } elseif ($result['ostatus'] == '2') {
                                    ?> 
                                <td style="text-align:center;"><a href="paymentstatus.php?shiftid=<?= $result['cmrId'] ?>&invid=<?= $result['invid'] ?>&orderid=<?= $result['oid'] ?>">Approved</a></td>
                                <?php
                                } elseif ($result['ostatus'] == '3') {
                                    ?> 
                                <td style="text-align:center;"><a href="paymentstatus.php?shiftid=<?= $result['cmrId'] ?>&invid=<?= $result['invid'] ?>&orderid=<?= $result['oid'] ?>">Ready to Ship</a></td>
                                <?php
                                } elseif ($result['ostatus'] == '4') {
                                    ?> 
                                <td style="text-align:center;"><a href="paymentstatus.php?shiftid=<?= $result['cmrId'] ?>&invid=<?= $result['invid'] ?>&orderid=<?= $result['oid'] ?>">Handover to Courier</a></td>
                                <?php
                                } elseif ($result['ostatus'] == '5') {
                                    ?> 
                                <td style="text-align:center;"><a href="paymentstatus.php?shiftid=<?= $result['cmrId'] ?>&invid=<?= $result['invid'] ?>&orderid=<?= $result['oid'] ?>">Delivered</a></td>
                                <?php
                                } else {
                                    ?>
							<?php
                                } ?>
                                <td style="text-align:center;"><a onclick="return confirm('Are you sure to delete?'); href="?delproid=<?= $result['cmrId'] ?>&invid=<?= $result['invid']; ?>&orderid=<?= $result['oid']; ?>">X</a></td>
                                <!--<td><a " href="?delpro=<?php echo $result['cartId']; ?>">X</a></td>-->
                            
						</tr>
						<?php
                            }
                        } ?>
					</tbody>
				</table>
               </div>
            </div>
        </div>
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
Offline PaidOffline Paid
        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php';?>
