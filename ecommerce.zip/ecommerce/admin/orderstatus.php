<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php
$filepath = realpath(dirname(__FILE__));
include_once($filepath.'/../classes/Cart.php');
$ct = new Cart();
$fm = new Format();
?>
<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['shiftid'])) {
    $id 	= $_GET['shiftid'];
    $time 	= $_GET['time'];
    $price 	= $_GET['price'];
    $orderStatus = $_POST['orderStatus'];
    $shift = $ct->productStatus($id, $time, $price, $orderStatus);
}

?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Update Order Status</h2>
               <div class="block copyblock">
               <?php 
               if (isset($shift)) {
                     echo $shift;
                 }
                ?>

                <form action="" method="post">
                    <table class="form">                    
                        <tr>
                            <td>
                                <label>Order Status</label>
                            </td>
                            <td>
                                <select id="select" name="orderStatus">
                                    <option value="0">Select Order Status</option>
                                    <option value="1">Order Placed</option>
                                    <option value="2">Order Approved</option>
                                    <option value="3">Order Ready to Ship</option>
                                    <option value="4">Order Handover to Courier</option>
                                    <option value="5">Order Delivered</option>
                                </select>
                            </td>
                        </tr>
                        <tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
<?php include 'inc/footer.php';?>