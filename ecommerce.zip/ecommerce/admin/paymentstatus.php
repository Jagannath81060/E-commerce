<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php
$filepath = realpath(dirname(__FILE__));
include_once($filepath.'/../classes/Cart.php');
$ct = new Cart();
$fm = new Format();
?>
<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['shiftid'])) {
    $id 	= $_GET['shiftid'];
    $time 	= $_GET['time'];
    $price 	= $_GET['price'];
    $paymentStatus = $_POST['paymentStatus'];
    $shift = $ct->paymentStatus($id, $time, $price, $paymentStatus);
}

?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Update Payment Status</h2>
               <div class="block copyblock">
               <?php 
               if (isset($shift)) {
                     echo $shift;
                 }
                ?>

                <form action="" method="post">
                    <table class="form">                    
                        <tr>
                            <td>
                                <label>Payment Status</label>
                            </td>
                            <td>
                                <select id="select" name="paymentStatus">
                                    <option value="0">Select Payment Status</option>
                                    <option value="1">Not Paid</option>
                                    <option value="2">Paid</option>
                                </select>
                            </td>
                        </tr>
                        <tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
<?php include 'inc/footer.php';?>