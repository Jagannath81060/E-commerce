 <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>Copyright &copy; 2020-<?php echo date("Y");?> <a href="https://www.qualitynutritionbd.com">Quality Nutrition.</a>. All Rights Reserved.</p>
    </div>
</body>
</html>
