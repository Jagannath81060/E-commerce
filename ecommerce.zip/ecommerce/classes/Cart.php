<?php
$filepath = realpath(dirname(__FILE__));
include_once($filepath.'/../lib/Database.php');
include_once($filepath.'/../helpers/Format.php');
 ?>
<?php 


class Cart
{
    private $db;
    private $fm;

    public function __construct()
    {
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function addToCart($quantity, $proId)
    {
        $quantity = $this->fm->validation($quantity);
        $quantity = mysqli_real_escape_string($this->db->link, $quantity);
        $proId = mysqli_real_escape_string($this->db->link, $proId);
        $sId = session_id();

        $squery = "SELECT * FROM tbl_product WHERE productId = '$proId'";
        $result = $this->db->select($squery)->fetch_assoc();
        $productName = $result['productName'];
        $price = $result['price']-$result['discount'];
        $image = $result['image'];

        $chquery = "SELECT * FROM tbl_cart WHERE productId = '$proId' AND sId = '$sId'";
        $getPro = $this->db->select($chquery);

        if ($getPro) {
            $msg = "Product Already Added";
            return $msg;
        } else {
            
            $query = "INSERT INTO tbl_cart (sId, productId, productName, price, quantity, image) VALUES ('$sId', '$proId', '$productName', '$price', '$quantity', '$image')";
            $inserted_row = $this->db->insert($query);
            
            if ($inserted_row) {
                header("Location:cart.php");
            } else {
                header("Location:404.php");
                
            }
        }
    }

    public function getCartProduct()
    {
        $sId = session_id();
        $query = "SELECT * FROM tbl_cart WHERE sId = '$sId'";
        $result = $this->db->select($query);
        return $result;
    }

    public function updateCartQuantity($cartId, $quantity)
    {
        $cartId     = mysqli_real_escape_string($this->db->link, $cartId);
        $quantity   = mysqli_real_escape_string($this->db->link, $quantity);
        $query = "UPDATE tbl_cart SET quantity = '$quantity' WHERE cartId = '$cartId'";
        $updated_row = $this->db->update($query);
        if ($updated_row) {
            header("Location:cart.php");
        } else {
            $msg = "<span class='error'>Quantity Not Updated.</span>";
            return $msg;
        }
    }
    public function delProductByCart($delProId)
    {
        $delProId   = mysqli_real_escape_string($this->db->link, $delProId);
        $query = "DELETE FROM tbl_cart WHERE cartId = '$delProId'";
        $deldata = $this->db->delete($query);
        if ($deldata) {
            echo "<script>window.location = 'cart.php'; </script>";
        } else {
            $msg = "<span class='error'>Product Not Deleted!</span>";
            return $msg;
        }
    }

    public function checkCartItem()
    {
        $sId = session_id();
        $query = "SELECT * FROM tbl_cart WHERE sId = '$sId'";
        $result = $this->db->select($query);
        return $result;
    }

    public function delCustomerCart()
    {
        $sId = session_id();
        $query = "DELETE FROM tbl_cart WHERE sId = '$sId'";
        $this->db->delete($query);
    }

    public function orderProduct($cmrId)
    {
        $cmrId = mysqli_real_escape_string($this->db->link, $cmrId);
        
        $query = "SELECT oid FROM tbl_order Where cmrId=$cmrId ORDER BY oid DESC LIMIT 1";
        $getLastOrder = $this->db->select($query);
        if ($getLastOrder) {
            $getLastOrder = $getLastOrder->fetch_assoc();
        }
        
        $getOrder=$getLastOrder['oid'];
        
        $getOrder++;
        
        if ($getOrder) {
            // Get the last Order ID
            $orderid = $getOrder;
        }
        
        $sId = session_id();
        $query = "SELECT * FROM tbl_cart WHERE sId = '$sId'";
        $getPro = $this->db->select($query);
        if ($getPro) {
            while ($result  = $getPro->fetch_assoc()) {
                $productId  = $result['productId'];
                $productName= $result['productName'];
                $quantity   = $result['quantity'];
                $price      = $result['price'] * $quantity;
                $image      = $result['image'];

                $query = "INSERT INTO tbl_order(oid, cmrId, productId, productName, quantity, price, image) VALUES ('$orderid', '$cmrId', '$productId', '$productName', '$quantity', '$price', '$image')";
                $inserted_row = $this->db->insert($query);
            }
        }
    }
    
    public function orderPaymentInfo($cmrId, $invqty, $method, $amount, $delivery, $transaction, $pdate, $pstatus, $odate, $ostatus)
    {
        $cmrId = mysqli_real_escape_string($this->db->link, $cmrId);
        $invqty = mysqli_real_escape_string($this->db->link, $invqty);
        $method = mysqli_real_escape_string($this->db->link, $method);
        $amount = mysqli_real_escape_string($this->db->link, $amount);
        $delivery = mysqli_real_escape_string($this->db->link, $delivery);
        $transaction = mysqli_real_escape_string($this->db->link, $transaction);
        $pdate = mysqli_real_escape_string($this->db->link, $pdate);
        $pstatus = mysqli_real_escape_string($this->db->link, $pstatus);
        $odate = mysqli_real_escape_string($this->db->link, $odate);
        $ostatus = mysqli_real_escape_string($this->db->link, $ostatus);
        
        $query = "SELECT invid FROM tbl_invoice ORDER BY invid DESC LIMIT 1";
        $getLastInv = $this->db->select($query);
        $getInv = $getLastInv->fetch_assoc();
        
        $getInv=$getInv['invid'];
        
        $getInv++;
        
        if ($getInv) {
            // Get the last inserted ID
            $invoiceid = $getInv;
            
            $query = "SELECT oid FROM tbl_order Where cmrId=$cmrId ORDER BY oid DESC LIMIT 1";
            $orderid = $this->db->select($query);
            $orderid = $orderid->fetch_assoc();
            $orderid=$orderid['oid'];
        }
        $query = "INSERT INTO tbl_invoice(invid, orderid, cmrId, invqty, method, amount, delivery, transaction, pdate, pstatus, odate, ostatus) VALUES ('$invoiceid', '$orderid', '$cmrId', '$invqty', '$method', '$amount', '$delivery', '$transaction', '$pdate', '$pstatus', '$odate', '$ostatus')";
        $inserted_row = $this->db->insert($query);
        
    }
    
    public function getInvoiceData($orderid)
    {
        $orderid  = mysqli_real_escape_string($this->db->link, $orderid);
        $query = "SELECT invid, odate, pdate, oid, o.cmrId, productName, quantity, price, invqty, amount, delivery FROM tbl_order as o, tbl_invoice as i WHERE o.oid=i.orderid and o.cmrId=i.cmrId and o.oid='$orderid'";
        $result = $this->db->select($query);
        return $result;
    }
    
    public function getInvoiceCustomerData($orderid)
    {
        $orderid  = mysqli_real_escape_string($this->db->link, $orderid);
        $query = "SELECT invid, orderid, invqty, method, amount, delivery, transaction, pdate, pstatus, odate, ostatus, id, name, address, city, country, zip, phone, email FROM tbl_invoice as i, tbl_customers as c WHERE c.id=i.cmrId and orderid='$orderid'";
        $result = $this->db->select($query);
        return $result;
    }
    
    public function getAllInvoice()
    {
        $query = "SELECT invid, odate, oid, o.cmrId, amount, invqty, ostatus, pstatus FROM tbl_order as o, tbl_invoice as i WHERE o.oid=i.orderid and o.cmrId=i.cmrId GROUP BY invid ORDER BY invid DESC;";
        $result = $this->db->select($query);
        return $result;
    }

    public function payableAmount($cmrId)
    {
        $cmrId  = mysqli_real_escape_string($this->db->link, $cmrId);
        $query = "SELECT price FROM tbl_order WHERE cmrId = '$cmrId' AND date = now()";
        $result = $this->db->select($query);
        return $result;
    }

    public function getOrderProduct($cmrId)
    {
        $cmrId  = mysqli_real_escape_string($this->db->link, $cmrId);
        $query = "SELECT * FROM tbl_order WHERE cmrId = '$cmrId' ORDER BY date DESC";
        $result = $this->db->select($query);
        return $result;
    }

    public function checkOrder($cmrId)
    {
        $cmrId  = mysqli_real_escape_string($this->db->link, $cmrId);
        $query = "SELECT * FROM tbl_order WHERE cmrId = '$cmrId'";
        $result = $this->db->select($query);
        return $result;
    }

    public function getAllOrderProduct($cmrId)
    {
        $cmrId  = mysqli_real_escape_string($this->db->link, $cmrId);
        $query = "SELECT * FROM tbl_invoice Where cmrId = '$cmrId' ORDER BY invid DESC";
        $result = $this->db->select($query);
        return $result;
    }

    public function productShifted($id, $time, $price)
    {
        $id     = mysqli_real_escape_string($this->db->link, $id);
        $time   = mysqli_real_escape_string($this->db->link, $time);
        $price  = mysqli_real_escape_string($this->db->link, $price);

        $query = "UPDATE tbl_order SET status = '1' WHERE cmrId = '$id' AND date = '$time' AND price = '$price'";
        $updated_row = $this->db->update($query);
        if ($updated_row) {
            $msg = "<span class='success'>Updated Successfully</span>";
            return $msg;
        } else {
            $msg = "<span class='error'>Not Updated.</span>";
            return $msg;
        }
    }
    
    public function orderStatus($cmrId, $invid, $oid, $orderStatus)
    {
        $cmrId     = mysqli_real_escape_string($this->db->link, $cmrId);
        $invid   = mysqli_real_escape_string($this->db->link, $invid);
        $oid  = mysqli_real_escape_string($this->db->link, $oid);
        $orderStatus = mysqli_real_escape_string($this->db->link, $orderStatus);
        
        $query = "UPDATE tbl_invoice SET ostatus = '$orderStatus' WHERE cmrId = '$cmrId' AND invid = '$invid' AND oid = '$oid'";
        $updated_row = $this->db->update($query);
        if ($updated_row) {
            $msg = "<span class='success'>Updated Successfully</span>";
            return $msg;
        } else {
            $msg = "<span class='error'>Not Updated.</span>";
            return $msg;
        }
    }
    
    public function paymentStatus($cmrId, $invid, $oid, $paymentStatus)
    {
        $cmrId     = mysqli_real_escape_string($this->db->link, $cmrId);
        $invid   = mysqli_real_escape_string($this->db->link, $invid);
        $oid  = mysqli_real_escape_string($this->db->link, $oid);
        $paymentStatus = mysqli_real_escape_string($this->db->link, $paymentStatus);
        
        $query = "UPDATE tbl_invoice SET pstatus = '$paymentStatus' WHERE cmrId = '$cmrId' AND invid = '$invid' AND oid = '$oid'";
        $updated_row = $this->db->update($query);
        if ($updated_row) {
            $msg = "<span class='success'>Updated Successfully</span>";
            return $msg;
        } else {
            $msg = "<span class='error'>Not Updated.</span>";
            return $msg;
        }
    }

    public function delProductShifted($cmrId, $invid, $oid)
    {
        $cmrId     = mysqli_real_escape_string($this->db->link, $cmrId);
        $invid   = mysqli_real_escape_string($this->db->link, $invid);
        $oid  = mysqli_real_escape_string($this->db->link, $oid);

        $query = "DELETE FROM tbl_order WHERE cmrId = '$cmrId' AND invid = '$invid' AND oid = '$oid'";
        $deldata = $this->db->delete($query);
        if ($deldata) {
            $msg = "<span class='success'>Data Deleted Successfully</span>";
            return $msg;
        } else {
            $msg = "<span class='error'>Data Not Deleted!</span>";
            return $msg;
        }
    }

    public function productShiftConfirm($cmrId, $invid, $oid)
    {
        $cmrId     = mysqli_real_escape_string($this->db->link, $cmrId);
        $invid   = mysqli_real_escape_string($this->db->link, $invid);
        $oid  = mysqli_real_escape_string($this->db->link, $oid);

        $query = "UPDATE tbl_invoice SET pstatus = '2' WHERE cmrId = '$cmrId' AND invid = '$invid' AND oid = '$oid'";
        $updated_row = $this->db->update($query);
        if ($updated_row) {
            $msg = "<span class='success'>Updated Successfully</span>";
            return $msg;
        } else {
            $msg = "<span class='error'>Not Updated.</span>";
            return $msg;
        }
    }
}
